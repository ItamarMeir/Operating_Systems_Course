// C program to implement cond(), signal()
// and wait() functions
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

// Declaration of thread condition variable
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;


// declaring mutex
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lock2 = PTHREAD_MUTEX_INITIALIZER;




// Deadlock Example
void* threadA()
{
	// acquire a lock1
	pthread_mutex_lock(&lock1);
	// acquire a lock2
	pthread_mutex_lock(&lock2);
    //
    //  CS
    //

    // release locks
	pthread_mutex_unlock(&lock2);
	pthread_mutex_unlock(&lock1);
	return NULL;
}
void* threadB()
{
	// acquire a lock2
	pthread_mutex_lock(&lock2);
	// acquire a lock1
	pthread_mutex_lock(&lock1);
    //
    //  CS
    //

    // release locks
	pthread_mutex_unlock(&lock1);
	pthread_mutex_unlock(&lock2);
	return NULL;
}

// Starvation Example
void* HighPriority()
{
	// acquire a lock
	pthread_mutex_lock(&lock);
    //
    //  CS
    //

    // release lock
	pthread_mutex_unlock(&lock);
	return NULL;
}
void* LowPriority()
{
	// acquire a lock
	pthread_mutex_lock(&lock);
    pthread_cond_wait(&cond, &lock); // wait for signal = no HighPriority
    //
    //  CS
    //

    // release lock
	pthread_mutex_unlock(&lock);

	return NULL;
}



//// 	START of Ex3A = MUTEX	////

typedef struct {
    pthread_mutex_t semaphore;
    pthread_t ownerID;               // Thread ID of the mutex lock user.
    int locked;
} mutexLock;

// create a mutex lock (in main)
void createMutex(mutexLock* mutex) {
    pthread_mutex_init(&mutex->semaphore, NULL);
    mutex->ownerID = 0;
    mutex->locked = 0;
}



// unlock the mutex
void mutex_unlock(mutexLock* mutex) {
    pthread_mutex_lock(&mutex->semaphore);
	//printf("Thread %lu tries to unlock mutex.\n", pthread_self());
    if (!mutex->locked || !pthread_equal(mutex->ownerID, pthread_self())) {
        //printf("Error: Mutex can only be unlocked by the thread that locked it.\n");
        pthread_mutex_unlock(&mutex->semaphore);
        return ;
    }
    mutex->ownerID = 0;    // Clear the owner
    mutex->locked = 0;   // Mark the mutex as unlocked
	//printf("Thread %lu UNLOCKED mutex.\n", pthread_self());
    pthread_mutex_unlock(&mutex->semaphore);
}

// lock the mutex
void mutex_lock(mutexLock* mutex) {
	int exit_flag=1;
	while(exit_flag) {
		//mutex_unlock(mutex); Enable to see that mutex lock works.
		pthread_mutex_lock(&mutex->semaphore);
		if(mutex->locked == 0) {
			mutex->ownerID = pthread_self(); // Set the current thread as the owner
			mutex->locked = 1;            // Mark the mutex as locked
			//printf("Thread %lu LOCKED mutex.\n", pthread_self());
			exit_flag = 0;
		}
		pthread_mutex_unlock(&mutex->semaphore);
	}
}

void* CS_func(void* arg) {
    mutexLock* mutex = (mutexLock*)arg;

    mutex_lock(mutex);
    printf("Thread %lu has entered the critical section.\n", pthread_self());

    //
    //  CS
    //

    printf("Thread %lu is leaving the critical section.\n", pthread_self());
    mutex_unlock(mutex);

    return NULL;
}

//// END of Ex3A = MUTEX	////



//// START of Ex3A = conVal	////

typedef struct {
	pthread_mutex_t mutex;  // Mutex to protect condition state
	int signal_flag;        // Flag indicating whether the condition is signaled
} condVal;

// create conVal in main
void createCondVal(condVal* condition) {
	pthread_mutex_init(&condition->mutex, NULL);
	condition->signal_flag = 0; // Initially, the condition is not signaled
}

void condValWait(condVal* condition) {
	// Do not save history of signal_flag
	pthread_mutex_lock(&condition->mutex); // Lock to check the signal_flag
	if (condition->signal_flag == 1) {
		condition->signal_flag = 0; // Reset the signal flag
	}
	pthread_mutex_unlock(&condition->mutex); // Release the signal check mutex
	// Wait for the signal
	while (1) {
		pthread_mutex_lock(&condition->mutex); // Lock to check the signal_flag
		if (condition->signal_flag == 1) {
			condition->signal_flag = 0; // Reset the signal flag
			pthread_mutex_unlock(&condition->mutex); // Release the signal check mutex
			break;
		}
		pthread_mutex_unlock(&condition->mutex); // Release the signal check mutex
		sleep(0.1);
	}
}

// First who catchs the signal exit waiting room.
void condValSignal(condVal* condition) {
	pthread_mutex_lock(&condition->mutex); // Lock to set the signal_flag
	condition->signal_flag = 1; // Set the signal flag
	pthread_mutex_unlock(&condition->mutex); // Release the signal check mutex
}

condVal condition;

void* worker() {
	printf("Worker %lu: Waiting for a signal.\n", pthread_self());
	condValWait(&condition);
	printf("Worker %lu: Received a signal!\n", pthread_self());

	return NULL;
}

// Signaler thread function
void* signaler() {
	printf("Signaler %lu: Goes to sleep for 2 seconds.\n", pthread_self());
	sleep(2);
	printf("Signaler %lu: WokeUp -> signal waiting thread.\n", pthread_self());
	condValSignal(&condition);

	return NULL;
}

//// END of Ex3A = conVal	////

//// START of Ex3B 	////

#define NUM_OF_SLOTS 2
int slotFollower=0;
condVal conditionProducer;
condVal conditionConsumer;

mutexLock mutexPart3;

void* Producer(void* arg) {
	mutexLock* mutex = (mutexLock*)arg;
	mutex_lock(mutex);
	while (slotFollower>=NUM_OF_SLOTS) { // no free slots
		printf("Producer %lu: goes to sleep MAXitems = %d.\n", pthread_self(),slotFollower);
		mutex_unlock(mutex);
		condValWait(&conditionProducer);
		mutex_lock(mutex);
		printf("Producer %lu: Woke Up.\n", pthread_self());
	}
	slotFollower++;
	printf("Producer: %lu -> Num of items= %d\n",pthread_self(), slotFollower);
	mutex_unlock(mutex);
	condValSignal(&conditionConsumer); // if consumer wants to take item - take it.
	return NULL;
}
void* Consumer(void* arg) {
	mutexLock* mutex = (mutexLock*)arg;
	mutex_lock(mutex);
	while (slotFollower<=0) {	// no items available.
		printf("Consumer %lu: goes to sleep NOitems = %d.\n", pthread_self(),slotFollower);
		mutex_unlock(mutex);
		condValWait(&conditionConsumer);
		mutex_lock(mutex);
		printf("Consumer %lu: Woke Up.\n", pthread_self());

	}
	slotFollower--;
	printf("Consumer: %lu -> Num of items= %d\n",pthread_self(), slotFollower);
	mutex_unlock(mutex);
	condValSignal(&conditionProducer);
	return NULL;
}


//// END of Ex3B 	////

//// START of Ex4 	////
#include <stdlib.h>
#include <string.h>

#define NUM_WRITERS 2
#define NUM_READERS 10
#define MAX_LINE_LENGTH 256

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_writer = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_reader = PTHREAD_COND_INITIALIZER;

char shared_line[MAX_LINE_LENGTH];
int line_available = 0;  // 1 if a line is ready to be read, 0 otherwise
int current_writerID = 0;
int total_lines_written=0;
int total_lines_read = 0;
FILE *source_file;
FILE *dest_file;

void *writer(void *arg) {
    int local_writer_id = *(int *)arg;
	free (arg);
    char line[MAX_LINE_LENGTH];

    while (1) {
        pthread_mutex_lock(&mutex);
    	//printf("Writer #%d: Entered CS.\n", local_writer_id);

    	if (current_writerID==-1) {
    		//printf("Writer #%d: FileFinished.\n", local_writer_id);
    		pthread_mutex_unlock(&mutex);
    		break;
    	}

        // Wait for the turn of this writer AND for line to be read
        while ((current_writerID != local_writer_id)||(line_available==1)) {
        	//printf("Writer #%d: Goes to Sleep, not my turn.\n", local_writer_id);
            pthread_cond_wait(&cond_writer, &mutex);
        	//printf("Writer #%d: WokeUp.\n", local_writer_id);
        	if (current_writerID==-1) { // if writer woke up to finished file.
        		//printf("Writer #%d: WokeUp -> FileFinished.\n", local_writer_id);
        		pthread_mutex_unlock(&mutex);
        		break;
        	}
        }

        // Read a line from the source file
        if (fgets(line, sizeof(line), source_file) == NULL) {
            current_writerID = -1;  // ERROR///Finished
        	//printf("Writer #%d: ReadFileEmpty.\n", local_writer_id);
        	// Wake up threads to finish.
            pthread_cond_broadcast(&cond_reader);
        	pthread_cond_broadcast(&cond_writer);
            pthread_mutex_unlock(&mutex);
            break;
        }

        // Write the line to the shared buffer and file
    	//printf("Writer #%d: **WRITING**.\n", local_writer_id);
        strcpy(shared_line, line);
        fprintf(dest_file, "Writer #%d: %s", local_writer_id, line);
        fflush(dest_file);

        line_available = 1;
    	total_lines_written++;
        current_writerID = (current_writerID + 1) % NUM_WRITERS;  // Alternate writers

        // Wake up readers
		pthread_cond_broadcast(&cond_reader);
        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

void *reader(void *arg) {
    int reader_id = *(int *)arg;
	free(arg);

    while (1) {
        pthread_mutex_lock(&mutex);
    	//printf("Reader #%d: Entered CS.\n", reader_id);

    	// Exit if all lines are read and end of file is reached
    	if (current_writerID==-1) {
    		pthread_mutex_unlock(&mutex);
    		break;
    	}

        // Wait for a line to be available and file not finished
        while (!line_available && current_writerID != -1) {
        	// while no line & not finished -> go to sleep
        	//printf("Reader #%d: Goes to Sleep -> NO LINE.\n", reader_id);
            pthread_cond_wait(&cond_reader, &mutex);
        	//printf("Reader #%d: Woke up.\n", reader_id);
        	if (current_writerID==-1) {	// if woke up to finished file
        		//printf("Reader #%d: Woke up and file FINISHED.\n", reader_id);
        		pthread_cond_broadcast(&cond_writer);
        		pthread_mutex_unlock(&mutex);
        		break;
        	}

        }


		// Error == fileFinished
        if (current_writerID == -1 && !line_available) {
            pthread_mutex_unlock(&mutex);
        	//printf("Reader #%d: FileFinished.\n", reader_id);
        	pthread_cond_broadcast(&cond_writer);
        	pthread_cond_broadcast(&cond_reader);
        	//printf("Exit2: File is Finished Signal, reader= %d\n",reader_id);
            break;
        }

        // Print the line
        printf("Reader #%d: %s", reader_id, shared_line);

        // Update the reader count
    	total_lines_read++;

    	line_available = 0;
    	pthread_cond_broadcast(&cond_writer);

        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}



//// END of Ex4 	////


int main() {
	// Part 1
	printf("******************\n");
	printf("START OF PART 1 --> Ex3A\n");
	printf("******************\n");
  	printf("In mutex_lock function, you can enable mutex_unlock to see that it works.\n");
    int num_threads = 5;
    pthread_t threads[num_threads];
    mutexLock mutex;

    // Initialize the mutex
    createMutex(&mutex);

    // Create threads
    for (int i = 0; i < num_threads; i++) {
        if (pthread_create(&threads[i], NULL, CS_func, &mutex) != 0) {
            perror("Thread creation failed");
            break;
        }
    }

    // Wait for all threads to finish
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
	printf("******************\n");
	printf("START OF PART 2 --> Ex3A\n");
	printf("******************\n");


    //Part 2
	// Create threads
	pthread_t threadsWorker[num_threads];
	pthread_t threadsSignaler[num_threads];
	createCondVal(&condition);


	for (int i = 0; i < num_threads; i++) {
		if (pthread_create(&threadsWorker[i], NULL, worker, NULL) != 0) {
			perror("Thread creation failed");
			break;
		}
		sleep(3);
		if (pthread_create(&threadsSignaler[i], NULL, signaler, NULL) != 0) {
			perror("Thread creation failed");
			break;
		}
	}

	// Wait for all threads to finish

	for (int i = 0; i < num_threads; i++) {
		pthread_join(threadsSignaler[i], NULL);
		pthread_join(threadsWorker[i], NULL);
	}





	printf("******************\n");
	printf("START OF Ex3B\n");
	printf("******************\n");




	//Part 3
	// Create threads
	pthread_t threadsProducer[num_threads];
	pthread_t threadsConsumer[num_threads];
	createCondVal(&conditionProducer);
	createCondVal(&conditionConsumer);

	//Check for MAXitems
	//pthread_t extra1, extra2;
	//pthread_create(&extra1, NULL, Producer,&mutexPart3 );
	//pthread_create(&extra2, NULL, Producer,&mutexPart3 );

	for (int i = 0; i < num_threads; i++) {
		if (pthread_create(&threadsProducer[i], NULL, Producer,&mutexPart3 ) != 0) {
			perror("Thread creation failed");
			break;
		}
		if (pthread_create(&threadsConsumer[i], NULL, Consumer, &mutexPart3) != 0) {
			perror("Thread creation failed");
			break;
		}
	}

	// Wait for all threads to finish

	for (int i = 0; i < num_threads; i++) {
		pthread_join(threadsProducer[i], NULL);
		pthread_join(threadsConsumer[i], NULL);
	}


	printf("******************\n");
	printf("START OF Ex4\n");
	printf("******************\n");

	//Part 4
	// Create threads
	pthread_t writers[NUM_WRITERS], readers[NUM_READERS];

	// Open the source and destination files
	source_file = fopen("file.txt", "r");
	if (!source_file) {
		perror("Error opening source file");
		return 1;
	}

	dest_file = fopen("new_file.txt", "w");
	if (!dest_file) {
		perror("Error opening destination file");
		fclose(source_file);
		return 1;
	}

	// Create writer threads
	for (int i = 0; i < NUM_WRITERS; i++) {
		int *arg = malloc(sizeof(int));
		*arg = i;
		pthread_create(&writers[i], NULL, writer, arg);
	}

	// Create reader threads
	for (int i = 0; i < NUM_READERS; i++) {
		int *arg = malloc(sizeof(int));
		*arg = i;
		pthread_create(&readers[i], NULL, reader, arg);
	}

	// Join writer threads
	for (int i = 0; i < NUM_WRITERS; i++) {
		pthread_join(writers[i], NULL);
		//printf("Writer thread %d has joined.\n", i);
	}

	// Join reader threads
	for (int i = 0; i < NUM_READERS; i++) {
		pthread_join(readers[i], NULL);
		//printf("Reader thread %d has joined.\n", i);
	}
	printf("\n");// just for terminal
	// Close files
	fclose(source_file);
	fclose(dest_file);



	return 0;
}