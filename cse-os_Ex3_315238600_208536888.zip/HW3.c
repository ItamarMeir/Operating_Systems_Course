#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // For usleep()
#include <time.h>
#include <pthread.h> // For thread creation

#define WORK_A 10000
#define WORK_B 1000
#define WORK_C 7000
#define ID_A 0.8
#define ID_B 0.5
#define ID_C 0.75

// Global variables
int turn=0;
int QUANTA = 1; // how many iter for each func (INT_MAX -> SJF/FIFO)

pthread_cond_t WaitingRoom = PTHREAD_COND_INITIALIZER;

pthread_mutex_t funcLock = PTHREAD_MUTEX_INITIALIZER;


clock_t start, end;


typedef struct {
    void* (*func)(void* args);
    int work_needs;
    int work_done;
    int complete;
    double work_time;
} thread_t;

void* theAnew(void* args);
void* theBnew(void* args);
void* theCnew(void* args);


thread_t threadData[3] = {
    {theAnew,WORK_A,0,0,0},
{theBnew,WORK_B,0,0,0},
{theCnew,WORK_C,0,0,0}
};

// in theInew funcs, there is lock start and end, and waiting room
// in waiting room all 3 threads will be sited.
// threads will be woken up, in broadcast.
// using turn, there will be a law of order
// which tread has the priority.
// data of thread will be saved in struct.
void* theAnew(void* args) {
    pthread_mutex_lock(&funcLock);
    while (turn != 0) {
		pthread_cond_wait(&WaitingRoom, &funcLock); //release lock.
    }
    if (!threadData[0].complete) {
        // turn = (turn+1)%3;
        for (int j=0;j<QUANTA;j++) {
            printf("Thread A: %d\n",threadData[0].work_done);
            threadData[0].work_done++;
            sleep(ID_A);
            if (threadData[0].work_done>WORK_A) {
                end = clock();
                threadData[0].work_time =  ((double) (end - start)) / CLOCKS_PER_SEC;
                threadData[0].complete++;
                pthread_mutex_unlock(&funcLock);
                break;
            }
        }
    }
    pthread_mutex_unlock(&funcLock);
}
void* theBnew(void* args) {
    pthread_mutex_lock(&funcLock);
    while (turn != 1) {
        pthread_cond_wait(&WaitingRoom, &funcLock); //release lock.
    }
    if (!threadData[1].complete) {
        // turn = (turn+1)%3;
        for (int j=0;j<QUANTA;j++) {
            printf("Thread B: %d\n",threadData[1].work_done);
            threadData[1].work_done++;
            sleep(ID_B);
            if (threadData[1].work_done>WORK_B) {
                end = clock();
                threadData[1].work_time =  ((double) (end - start)) / CLOCKS_PER_SEC;
                threadData[1].complete++;
                pthread_mutex_unlock(&funcLock);
                break;
            }
        }
    }
    pthread_mutex_unlock(&funcLock);
}
void* theCnew(void* args) {
    pthread_mutex_lock(&funcLock);

    while (turn != 2) {
        pthread_cond_wait(&WaitingRoom, &funcLock);//release lock.
    }

    // turn = (turn+1)%3;
    if (!threadData[2].complete) {
        for (int j=0;j<QUANTA;j++) {
            printf("Thread C: %d\n",threadData[2].work_done);
            threadData[2].work_done++;
            sleep(ID_C);
            if (threadData[2].work_done>WORK_C) {
                end = clock();
                threadData[2].work_time =  ((double) (end - start)) / CLOCKS_PER_SEC;
                threadData[2].complete++;
                pthread_mutex_unlock(&funcLock);
                break;
            }
        }
    }
    pthread_mutex_unlock(&funcLock);

}





double RRnew() {

    pthread_t tid0, tid1, tid2;

    double RRTimer=0;

    turn=0;
    QUANTA =1;

    start = clock();
    while (!(threadData[0].complete) ||
        (!threadData[1].complete) ||
        (!threadData[2].complete)){
        turn =0;
        pthread_create(&tid0, NULL, theAnew, NULL);
        pthread_join(tid0, NULL);
        turn =1;
        pthread_create(&tid1, NULL, theBnew, NULL);
        pthread_join(tid1, NULL);
        turn =2;
        pthread_create(&tid2, NULL, theCnew, NULL);
        pthread_join(tid2, NULL);

        // pthread_mutex_lock(&funcLock);
        // turn = (turn+1)%3;
        // pthread_mutex_unlock(&funcLock);


        pthread_cond_broadcast(&WaitingRoom);
        // wake up all, only turn will continue
        // else, go back to sleep
        }
    RRTimer = threadData[0].work_time + threadData[1].work_time +
                threadData[2].work_time;

    pthread_cancel(tid0);
    pthread_cancel(tid1);
    pthread_cancel(tid2);

    return  (RRTimer/3);
}


double SJFnew() {

    pthread_t tid0, tid1, tid2;

    double SJFTimer=0;

    turn=0;
    QUANTA = INT_MAX;

    double min=ID_A*WORK_A;;
    int minIndx=0;

    threadData[0].work_time=ID_A*WORK_A;
    threadData[1].work_time=ID_B*WORK_B;
    if (threadData[1].work_time<min){min=threadData[1].work_time; minIndx=1;}
    threadData[2].work_time=ID_C*WORK_C;
    if (threadData[2].work_time<min){min=threadData[2].work_time; minIndx=2;}

    int otherIndx1 = (minIndx+1)%3;
    int otherIndx2 = (minIndx+2)%3;
    int temp=0;
    if (threadData[otherIndx1].work_time>threadData[otherIndx2].work_time) {
        temp = otherIndx1;
        otherIndx1=otherIndx2;
        otherIndx2 = temp;
    }
    // mid will always be otherIndx1
    // last will always be otherIndx2
    int turnArr[]={minIndx,otherIndx1,otherIndx2};
    double (*operations[])() = {theAnew, theBnew, theCnew};

    // turn -> global, each theI func looks on it.
    turn=0;
    int turnLocal=0;

    start = clock();

    while (!(threadData[0].complete) ||
        (!threadData[1].complete) ||
        (!threadData[2].complete)){
        turn = turnArr[turnLocal];
        pthread_create(&tid0, NULL, *operations[turn], NULL);
        pthread_join(tid0, NULL);


        pthread_mutex_lock(&funcLock);
        turnLocal =(turnLocal+1)%3;
        pthread_mutex_unlock(&funcLock);


        pthread_cond_broadcast(&WaitingRoom);
        // wake up all, only turn will continue
        // else, go back to sleep
        }
    SJFTimer = threadData[0].work_time + threadData[1].work_time +
                threadData[2].work_time;


    return  (SJFTimer/3);
}

double FIFOnew() {

    pthread_t tid0, tid1, tid2;

    double FIFOTimer=0;

    turn=0;
    QUANTA = INT_MAX;


    int ArrivalSet[]={0,1,2};
    double (*operations[])() = {theAnew, theBnew, theCnew};

    // turn -> global, each theInew func looks on it.
    turn=0;
    int turnLocal=0;

    start = clock();

    while (!(threadData[0].complete) ||
        (!threadData[1].complete) ||
        (!threadData[2].complete)){
        turn = ArrivalSet[turnLocal];
        pthread_create(&tid0, NULL, *operations[turn], NULL);
        pthread_join(tid0, NULL);


        pthread_mutex_lock(&funcLock);
        turnLocal =(turnLocal+1)%3;
        pthread_mutex_unlock(&funcLock);


        pthread_cond_broadcast(&WaitingRoom);
        // wake up all, only turn will continue
        // else, go back to sleep
        }
    FIFOTimer = threadData[0].work_time + threadData[1].work_time +
                threadData[2].work_time;


    return  (FIFOTimer/3);
}


// reset critical data about threads data
void cleanthreadsData() {
    for (int i=0;i<3;i++) {
        threadData[i].complete=0;
        threadData[i].work_done=0;
    }
}



int main() {

    cleanthreadsData();
    double RRtimer = RRnew();

    cleanthreadsData();
    double SJFtimer = SJFnew();

    cleanthreadsData();
    double FIFOtimer = FIFOnew();

    printf("RRTimer is %f\n", RRtimer);
    printf("SJFtimer is %f\n", SJFtimer);
    printf("FIFOtimer is %f\n", FIFOtimer);



    // Destroy mutex and condition variable
    pthread_mutex_destroy(&funcLock);
    pthread_cond_destroy(&WaitingRoom);

    return 0;
}